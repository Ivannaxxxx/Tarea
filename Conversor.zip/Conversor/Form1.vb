﻿Public Class Form1
    ' Constantes de Masa
    Private Const KILO As Double = 1000
    Private Const HECTO As Double = 100
    Private Const DECA As Double = 10
    Private Const GRAMO As Double = 1
    Private Const DECI As Double = 0.1
    Private Const CENTI As Double = 0.01
    Private Const MILI As Double = 0.001

    ' Constantes de Distancia
    Private Const KILOMETRO As Double = 1000
    Private Const METRO As Double = 1
    Private Const DECIMETRO As Double = 0.1
    Private Const CENTIMETRO As Double = 0.01
    Private Const MILIMETRO As Double = 0.001

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim unidadesMasa() As String = {"KILO", "HECTO", "DECA", "GRAMO", "DECI", "CENTI", "MILI"}
        Dim unidadesDistancia() As String = {"KILOMETRO", "METRO", "DECIMETRO", "CENTIMETRO", "MILIMETRO"}

        ComboBox3.Items.AddRange(New String() {"Masa", "Distancia"})
        ComboBox3.SelectedIndex = 0

        ComboBox1.Items.AddRange(unidadesMasa)
        ComboBox2.Items.AddRange(unidadesMasa)
        ComboBox1.SelectedIndex = 3 ' GRAMO como valor por defecto
        ComboBox2.SelectedIndex = 3 ' GRAMO como valor por defecto
    End Sub

    Private Sub TbxCantidad_TextChanged(sender As Object, e As EventArgs) Handles TbxCantidad.TextChanged
        RealizarConversion()
    End Sub

    Private Sub ComboBoxOrigen_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        RealizarConversion()
    End Sub

    Private Sub ComboBoxDestino_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        RealizarConversion()
    End Sub

    Private Sub ComboBoxTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        Dim tipoSeleccionado As String = ComboBox3.SelectedItem.ToString()

        If tipoSeleccionado = "Masa" Then
            ActualizarComboBoxes({"KILO", "HECTO", "DECA", "GRAMO", "DECI", "CENTI", "MILI"}, 3)
        ElseIf tipoSeleccionado = "Distancia" Then
            ActualizarComboBoxes({"KILOMETRO", "METRO", "DECIMETRO", "CENTIMETRO", "MILIMETRO"}, 1)
        End If

        RealizarConversion()
    End Sub

    Private Sub ActualizarComboBoxes(unidades() As String, indicePorDefecto As Integer)
        ComboBox1.Items.Clear()
        ComboBox2.Items.Clear()

        ComboBox1.Items.AddRange(unidades)
        ComboBox2.Items.AddRange(unidades)

        ComboBox1.SelectedIndex = indicePorDefecto
        ComboBox2.SelectedIndex = indicePorDefecto
    End Sub

    Private Sub RealizarConversion()
        Dim cantidadIngresada As Double

        If Not Double.TryParse(TbxCantidad.Text, cantidadIngresada) Then
            tbx_resultado.Text = "Valor no válido."
            Return
        End If

        Dim unidadOrigenSeleccionada As String = ComboBox1.SelectedItem.ToString()
        Dim unidadDestinoSeleccionada As String = ComboBox2.SelectedItem.ToString()

        Dim factorOrigen As Double = ObtenerFactor(unidadOrigenSeleccionada, ComboBox3.SelectedItem.ToString())
        Dim factorDestino As Double = ObtenerFactor(unidadDestinoSeleccionada, ComboBox3.SelectedItem.ToString())

        ' Verificar si los factores son válidos antes de realizar la conversión.
        If factorOrigen <= 0 Or factorDestino <= 0 Then
            tbx_resultado.Text = "Error: Unidad no válida."
            Return
        End If

        Dim cantidadConvertida As Double = cantidadIngresada * factorOrigen / factorDestino

        tbx_resultado.Text = cantidadConvertida.ToString("F3")
    End Sub

    Private Function ObtenerFactor(unidad As String, tipo As String) As Double
        Select Case tipo.ToUpper()
            Case "MASA"
                Select Case unidad.ToUpper()
                    Case "KILO" : Return KILO
                    Case "HECTO" : Return HECTO
                    Case "DECA" : Return DECA
                    Case "GRAMO" : Return GRAMO
                    Case "DECI" : Return DECI
                    Case "CENTI" : Return CENTI
                    Case "MILI" : Return MILI
                End Select

            Case "DISTANCIA"
                Select Case unidad.ToUpper()
                    Case "KILOMETRO" : Return KILOMETRO
                    Case "METRO" : Return METRO
                    Case "DECIMETRO" : Return DECIMETRO
                    Case "CENTIMETRO" : Return CENTIMETRO
                    Case "MILIMETRO" : Return MILIMETRO
                End Select

            Case Else : Return -1 ' Valor por defecto si no coincide con ninguna categoría.
        End Select

        Return -1 ' Valor por defecto en caso de que no se encuentre la unidad.
    End Function

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class