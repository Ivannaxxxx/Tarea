﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        ComboBox1 = New ComboBox()
        ComboBox2 = New ComboBox()
        ComboBox3 = New ComboBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        tbx_resultado = New TextBox()
        TbxCantidad = New TextBox()
        SuspendLayout()
        ' 
        ' ComboBox1
        ' 
        ComboBox1.FormattingEnabled = True
        ComboBox1.Location = New Point(304, 234)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(149, 33)
        ComboBox1.TabIndex = 0
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(304, 360)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(149, 33)
        ComboBox2.TabIndex = 1
        ' 
        ' ComboBox3
        ' 
        ComboBox3.FormattingEnabled = True
        ComboBox3.Location = New Point(307, 133)
        ComboBox3.Name = "ComboBox3"
        ComboBox3.Size = New Size(135, 33)
        ComboBox3.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BorderStyle = BorderStyle.Fixed3D
        Label1.FlatStyle = FlatStyle.Popup
        Label1.Font = New Font("MV Boli", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.Indigo
        Label1.ImageKey = "(none)"
        Label1.Location = New Point(179, 26)
        Label1.Name = "Label1"
        Label1.Size = New Size(428, 48)
        Label1.TabIndex = 3
        Label1.Text = "Convertidor de unidades"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Thistle
        Label2.ForeColor = SystemColors.ControlDarkDark
        Label2.Location = New Point(107, 244)
        Label2.Name = "Label2"
        Label2.Size = New Size(171, 25)
        Label2.TabIndex = 4
        Label2.Text = "Cantidad a convertir"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Thistle
        Label3.ForeColor = SystemColors.ControlDarkDark
        Label3.Location = New Point(107, 140)
        Label3.Name = "Label3"
        Label3.Size = New Size(183, 25)
        Label3.TabIndex = 5
        Label3.Text = "Unidad para convertir"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Thistle
        Label4.ForeColor = SystemColors.ControlDarkDark
        Label4.Location = New Point(143, 360)
        Label4.Name = "Label4"
        Label4.Size = New Size(90, 25)
        Label4.TabIndex = 6
        Label4.Text = "Resultado"
        ' 
        ' tbx_resultado
        ' 
        tbx_resultado.Location = New Point(498, 360)
        tbx_resultado.Name = "tbx_resultado"
        tbx_resultado.Size = New Size(150, 31)
        tbx_resultado.TabIndex = 7
        ' 
        ' TbxCantidad
        ' 
        TbxCantidad.Location = New Point(498, 236)
        TbxCantidad.Name = "TbxCantidad"
        TbxCantidad.Size = New Size(150, 31)
        TbxCantidad.TabIndex = 8
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Plum
        ClientSize = New Size(800, 450)
        Controls.Add(TbxCantidad)
        Controls.Add(tbx_resultado)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(ComboBox3)
        Controls.Add(ComboBox2)
        Controls.Add(ComboBox1)
        Name = "Form1"
        RightToLeftLayout = True
        Text = "Sistema conversor de unidades"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents tbx_resultado As TextBox
    Friend WithEvents TbxCantidad As TextBox

End Class
